class HomeController < ApplicationController
  def checkr
  end

  def flynn
  end

  def sparks
  end
end
